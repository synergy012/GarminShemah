Garmin Bedtime Shema — FR970 REVIEW COPY

Forerunner 970 only. Source commit: 3430b880658b376d9886fff49621ee6f4dc0ed46

Extract fr970.review.prg from this ZIP before transferring it to your watch.
Using Garmin's supported USB/file-transfer method, copy the PRG to the watch's
GARMIN/APPS folder, then safely disconnect and find it in the watch's app list.
This is a development-signed review build; physical-watch installation has not
yet been verified. It is not a Connect IQ Store release.

Ashkenaz, Sefard and Edot HaMizrach are included with three text sizes.
The text remains pending editorial approval. The selected Edot source
abbreviates Yoshev Beseter; missing verses were not filled from other sources.

Display changes: source markup parsed, whitespace collapsed, instructions
separated and labelled. Hebrew wording, vowels and punctuation retained.
Text sources and license links are also available in the app's settings.
See TEXT-NOTICES.md and the font license files included here.

Repository: https://github.com/synergy012/GarminShemah
