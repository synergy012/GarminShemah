Garmin Bedtime Shema — FR970 REVIEW COPY

Source commit: 4931d2aa5adba9c2dc8affa2438f4c95659cb592
Forerunner 970 only. Extract fr970.review.prg before copying it to GARMIN/APPS
using Garmin's supported USB/file-transfer method. Safely disconnect afterward.
To update an existing installation, close the app first and use the same transfer
process. The installed app uses the same application ID and development key.

Use left-side UP/DOWN to scroll. Bottom-right BACK saves your place and exits
immediately. Top-right START does not scroll; it selects items inside menus.
Hold the middle-left UP/MENU button while reading to open settings.
Scrolling: By screen (default, immediate steps with a line of overlap) / By line.
Instructions: Hidden (default) / Shown.
Shema paragraphs 2 + 3: Shown (default) / Hidden.
All three nuschaos and font sizes remain available. Settings are saved.
Prayer text in small print and conditional prayer passages remain included when
instructions are hidden. Source text is retained; visibility changes only reading.

Development-signed review build, pending editorial approval; not a store release.
The selected Edot source abbreviates Yoshev Beseter. No missing verses were filled
from another edition. Physical-watch update acceptance remains to be checked.

Display changes: markup parsed, whitespace collapsed, instructions separated and
labelled; reader settings can hide instructions or Shema paragraphs 2 and 3.
Hebrew wording, vowels and punctuation are retained in the bundled source assets.
See TEXT-NOTICES.md and the included font licenses. Offline source attribution is
also available through the app's Text sources setting.

Repository: https://github.com/synergy012/GarminShemah
