Garmin Bedtime Shema — FR970 REVIEW COPY

Source commit: 312ee01908cfb8803e982d3194278221aa0c5ce6
Forerunner 970 only. Extract fr970.review.prg before copying it to GARMIN/APPS
using Garmin's supported USB/file-transfer method. Safely disconnect afterward.
To update an existing installation, close the app first and use the same transfer
process. The installed app uses the same application ID and development key.

Hold the middle-left UP/MENU button while reading to open settings.
Scrolling: By screen (default, immediate steps with a line of overlap) / By line.
Instructions: Hidden (default) / Shown.
Shema paragraphs 2 + 3: Shown (default) / Hidden.
All three nuschaos and font sizes remain available. Settings are saved.
Prayer text in small print and conditional prayer passages remain included when
instructions are hidden. Source text is retained; visibility changes only reading.

Development-signed review build, pending editorial approval; not a store release.
The selected Edot source abbreviates Yoshev Beseter. No missing verses were filled
from another edition. Physical-watch update acceptance remains to be checked.

Display changes: markup parsed, whitespace collapsed, instructions separated and
labelled; reader settings can hide instructions or Shema paragraphs 2 and 3.
Hebrew wording, vowels and punctuation are retained in the bundled source assets.
See TEXT-NOTICES.md and the included font licenses. Offline source attribution is
also available through the app's Text sources setting.

Repository: https://github.com/synergy012/GarminShemah
